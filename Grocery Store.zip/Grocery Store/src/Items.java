//Items class
public class Items {
    String name = null;
    String price =  null;
    
    
    public Items (String name, String price) {
        this.name = name;
        this.price = price;
    }
    
    public String getName(){
        return name;
    }
    
    public String getPrice(){
        return price;
    }
    
}
